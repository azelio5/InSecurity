export const AppConstants = {
    BACEND_URL: 'http://localhost:8080/api/v1.0',
}